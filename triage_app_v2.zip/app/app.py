"""
app.py — Triage PWA Backend (Flask)
====================================
Authors: Sarthak Gupta, Dhruv
Guide: Dr R. Madhura

Run: python app/app.py
Then open http://localhost:5000 on your phone (same WiFi)
On Android: Chrome menu → "Add to Home Screen" → installs as app!
====================================
"""

import os
import sys
import json
import pickle
import re
import numpy as np
from flask import Flask, render_template, request, jsonify, send_from_directory

# =====================================================================
# SETUP
# =====================================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.join(BASE_DIR, '..')
MODEL_DIR = os.path.join(PROJECT_DIR, 'models')
DATA_DIR = os.path.join(PROJECT_DIR, 'data', 'processed')

app = Flask(__name__,
            template_folder=os.path.join(BASE_DIR, 'templates'),
            static_folder=os.path.join(BASE_DIR, 'static'))

# =====================================================================
# LOAD ALL MODELS (once at startup)
# =====================================================================
print("Loading models...")

# Vitals models
with open(os.path.join(MODEL_DIR, 'vitals_model_risk_level.pkl'), 'rb') as f:
    vitals_risk_model = pickle.load(f)
with open(os.path.join(MODEL_DIR, 'vitals_model_urgency.pkl'), 'rb') as f:
    vitals_urgency_model = pickle.load(f)
with open(os.path.join(MODEL_DIR, 'vitals_model_disease_category.pkl'), 'rb') as f:
    vitals_disease_model = pickle.load(f)

# NLP models
with open(os.path.join(MODEL_DIR, 'tfidf_vectorizer.pkl'), 'rb') as f:
    tfidf = pickle.load(f)
with open(os.path.join(MODEL_DIR, 'nlp_model_risk_level.pkl'), 'rb') as f:
    nlp_risk_model = pickle.load(f)
with open(os.path.join(MODEL_DIR, 'nlp_model_urgency.pkl'), 'rb') as f:
    nlp_urgency_model = pickle.load(f)
with open(os.path.join(MODEL_DIR, 'nlp_model_disease_category.pkl'), 'rb') as f:
    nlp_disease_model = pickle.load(f)

# Scaler and encoders
with open(os.path.join(DATA_DIR, 'scaler.pkl'), 'rb') as f:
    scaler = pickle.load(f)
with open(os.path.join(DATA_DIR, 'label_encoders.pkl'), 'rb') as f:
    label_encoders = pickle.load(f)

# Fusion config
with open(os.path.join(MODEL_DIR, 'fusion_config.json'), 'r') as f:
    fusion_config = json.load(f)

fusion_weights = fusion_config['optimal_weights']

# Metadata
with open(os.path.join(DATA_DIR, 'metadata.json'), 'r') as f:
    metadata = json.load(f)

print("All models loaded successfully!")

# =====================================================================
# LABEL MAPPINGS
# =====================================================================
RISK_LABELS = {0: 'Low', 1: 'Moderate', 2: 'High', 3: 'Critical'}
URGENCY_LABELS = {0: 'Non-Urgent', 1: 'Semi-Urgent', 2: 'Urgent', 3: 'Emergency'}
DISEASE_LABELS = {i: name for i, name in enumerate(label_encoders['disease_category'].classes_)}

RISK_COLORS = {0: '#22C55E', 1: '#F59E0B', 2: '#F97316', 3: '#DC2626'}
URGENCY_COLORS = {0: '#22C55E', 1: '#3B82F6', 2: '#F59E0B', 3: '#DC2626'}

URGENCY_ACTIONS = {
    0: 'Patient can wait. Schedule routine follow-up.',
    1: 'See within 1 hour. Monitor vitals.',
    2: 'See within 15 minutes. Prepare intervention.',
    3: 'IMMEDIATE attention. Activate emergency protocol.'
}

# =====================================================================
# RED FLAG ENGINE (inline for simplicity)
# =====================================================================
CRITICAL_KEYWORDS = ['unconscious', 'unresponsive', 'not breathing', 'cardiac arrest',
                     'agonal', 'pulseless', 'respiratory arrest']
HIGH_DANGER_KEYWORDS = ['seizure', 'hemorrhage', 'crushing chest pain', 'stroke',
                        'facial drooping', 'anaphylaxis', 'cyanotic', 'septic shock',
                        'chest pain radiating', 'meningitis', 'neck stiffness']
WARNING_KEYWORDS = ['difficulty breathing', 'vomiting blood', 'severe dehydration',
                    'worst headache', 'chest pain', 'confusion', 'high fever']

def check_red_flags(vitals, symptom_text):
    """Check for clinical red flags."""
    flags = []
    text_lower = symptom_text.lower()

    # Vital sign checks
    if vitals.get('spo2_percent', 100) < 85:
        flags.append({'severity': 'critical', 'message': f"SpO2 critically low ({vitals['spo2_percent']}%)"})
    elif vitals.get('spo2_percent', 100) < 90:
        flags.append({'severity': 'high', 'message': f"SpO2 dangerously low ({vitals['spo2_percent']}%)"})

    if vitals.get('bp_systolic_mmhg', 120) < 80:
        flags.append({'severity': 'critical', 'message': f"BP indicates shock ({vitals['bp_systolic_mmhg']} mmHg)"})
    elif vitals.get('bp_systolic_mmhg', 120) > 200:
        flags.append({'severity': 'critical', 'message': f"Hypertensive crisis ({vitals['bp_systolic_mmhg']} mmHg)"})

    if vitals.get('heart_rate_bpm', 75) > 160:
        flags.append({'severity': 'high', 'message': f"Heart rate dangerously high ({vitals['heart_rate_bpm']} bpm)"})
    elif vitals.get('heart_rate_bpm', 75) < 40:
        flags.append({'severity': 'high', 'message': f"Heart rate dangerously low ({vitals['heart_rate_bpm']} bpm)"})

    if vitals.get('temperature_c', 37) > 41.0:
        flags.append({'severity': 'high', 'message': f"Hyperpyrexia ({vitals['temperature_c']}°C)"})
    elif vitals.get('temperature_c', 37) < 34.5:
        flags.append({'severity': 'high', 'message': f"Severe hypothermia ({vitals['temperature_c']}°C)"})

    if vitals.get('respiratory_rate', 16) > 35:
        flags.append({'severity': 'high', 'message': f"Respiratory rate critically high ({vitals['respiratory_rate']})"})

    if vitals.get('blood_glucose_mg', 100) < 50:
        flags.append({'severity': 'high', 'message': f"Severe hypoglycemia ({vitals['blood_glucose_mg']} mg/dL)"})
    elif vitals.get('blood_glucose_mg', 100) > 400:
        flags.append({'severity': 'high', 'message': f"Suspected DKA ({vitals['blood_glucose_mg']} mg/dL)"})

    # Keyword checks
    for kw in CRITICAL_KEYWORDS:
        if kw in text_lower:
            flags.append({'severity': 'critical', 'message': f'Critical symptom: "{kw}"'})
    for kw in HIGH_DANGER_KEYWORDS:
        if kw in text_lower:
            flags.append({'severity': 'high', 'message': f'Danger sign: "{kw}"'})
    for kw in WARNING_KEYWORDS:
        if kw in text_lower:
            flags.append({'severity': 'warning', 'message': f'Warning: "{kw}"'})

    # Combinations
    if vitals.get('temperature_c', 37) > 38.5 and 'neck stiffness' in text_lower:
        flags.append({'severity': 'critical', 'message': 'Fever + neck stiffness → suspected meningitis'})
    if vitals.get('heart_rate_bpm', 75) > 110 and 'chest pain' in text_lower:
        flags.append({'severity': 'high', 'message': 'Tachycardia + chest pain → suspected MI'})

    shock_index = vitals.get('heart_rate_bpm', 75) / max(vitals.get('bp_systolic_mmhg', 120), 1)
    if shock_index > 1.2:
        flags.append({'severity': 'high', 'message': f'Shock index elevated ({shock_index:.2f})'})

    return flags


# =====================================================================
# PREDICTION FUNCTION
# =====================================================================
def predict_triage(vitals, symptom_text):
    """Run the complete multi-modal triage pipeline."""

    # --- Step 1: Compute derived features ---
    news_score = compute_news_score(vitals)
    map_mmhg = round((vitals['bp_systolic_mmhg'] + 2 * vitals['bp_diastolic_mmhg']) / 3, 1)
    shock_index = round(vitals['heart_rate_bpm'] / max(vitals['bp_systolic_mmhg'], 1), 2)
    pulse_pressure = vitals['bp_systolic_mmhg'] - vitals['bp_diastolic_mmhg']

    # --- Step 2: Build feature vector (must match training order!) ---
    age_group_map = {'Neonate': 0, 'Infant': 1, 'Child': 2, 'Adolescent': 3, 'Adult': 4, 'Elderly': 5}
    age = vitals.get('age', 30)
    if age < 0.083: ag = 0
    elif age < 1: ag = 1
    elif age < 12: ag = 2
    elif age < 18: ag = 3
    elif age < 60: ag = 4
    else: ag = 5

    consciousness_map = {'Alert': 0, 'Voice': 1, 'Pain': 2, 'Unresponsive': 3}
    consciousness_val = consciousness_map.get(vitals.get('consciousness', 'Alert'), 0)

    # Check red flags for feature vector
    red_flags = check_red_flags(vitals, symptom_text)
    has_critical = any(f['severity'] == 'critical' for f in red_flags)
    has_high = any(f['severity'] == 'high' for f in red_flags)
    has_warning = any(f['severity'] == 'warning' for f in red_flags)
    any_red = 1 if red_flags else 0
    red_count = min(len([f for f in red_flags if f['severity'] in ['critical', 'high']]), 3)

    # Chief complaint encoding (default 0)
    chief_complaint_enc = 0

    # Build raw feature array (36 features in training order)
    raw_features = np.array([
        age, vitals.get('gender', 1), vitals.get('weight_kg', 70),
        vitals.get('is_pregnant', 0), ag,
        vitals['heart_rate_bpm'], vitals['bp_systolic_mmhg'], vitals['bp_diastolic_mmhg'],
        vitals['temperature_c'], vitals['spo2_percent'], vitals['respiratory_rate'],
        vitals.get('blood_glucose_mg', 100), vitals.get('pain_score', 5), consciousness_val,
        news_score, map_mmhg, shock_index, pulse_pressure,
        vitals.get('has_diabetes', 0), vitals.get('has_hypertension', 0),
        vitals.get('has_heart_disease', 0), vitals.get('has_asthma_copd', 0),
        vitals.get('has_immunocompromised', 0), vitals.get('comorbidity_count', 0),
        1 if has_high else 0, 1 if has_warning else 0, 1 if has_critical else 0,
        any_red, red_count,
        0, 0, vitals.get('nearest_hospital_km', 25), 0,
        0, 0, chief_complaint_enc,
    ]).reshape(1, -1)

    # Scale numerical features
    numerical_indices = [0,1,2,5,6,7,8,9,10,11,12,14,15,16,17,23,28]
    try:
        raw_features[0, numerical_indices] = scaler.transform(
            raw_features[:, numerical_indices].reshape(1, -1)
        )[0]
    except:
        pass  # If scaling fails, use raw values

    # Replace NaN with 0
    raw_features = np.nan_to_num(raw_features, nan=0.0)

    # --- Step 3: Vitals model predictions ---
    vitals_risk_prob = vitals_risk_model.predict_proba(raw_features)[0]
    vitals_urgency_prob = vitals_urgency_model.predict_proba(raw_features)[0]
    vitals_disease_prob = vitals_disease_model.predict_proba(raw_features)[0]

    # --- Step 4: NLP model predictions ---
    text_clean = re.sub(r'[^a-z0-9\s\.]', '', symptom_text.lower())
    text_tfidf = tfidf.transform([text_clean])

    nlp_risk_prob = nlp_risk_model.predict_proba(text_tfidf)[0]
    nlp_urgency_prob = nlp_urgency_model.predict_proba(text_tfidf)[0]
    nlp_disease_prob = nlp_disease_model.predict_proba(text_tfidf)[0]

    # --- Step 5: Fusion ---
    w_risk = fusion_weights['risk_level']
    w_urgency = fusion_weights['urgency']
    w_disease = fusion_weights['disease_category']

    fused_risk_prob = w_risk['vitals_weight'] * vitals_risk_prob + w_risk['nlp_weight'] * nlp_risk_prob
    fused_urgency_prob = w_urgency['vitals_weight'] * vitals_urgency_prob + w_urgency['nlp_weight'] * nlp_urgency_prob
    fused_disease_prob = w_disease['vitals_weight'] * vitals_disease_prob + w_disease['nlp_weight'] * nlp_disease_prob

    risk_pred = int(np.argmax(fused_risk_prob))
    urgency_pred = int(np.argmax(fused_urgency_prob))
    disease_pred = int(np.argmax(fused_disease_prob))

    # --- Step 6: Red flag overrides ---
    if has_critical:
        risk_pred = max(risk_pred, 3)
        urgency_pred = max(urgency_pred, 3)
    elif has_high:
        risk_pred = max(risk_pred, 2)
        urgency_pred = max(urgency_pred, 2)

    # --- Step 7: Build explanation ---
    explanation = []
    explanation.append(f"NEWS Score: {news_score} (computed from vitals)")
    explanation.append(f"Shock Index: {shock_index} ({'normal' if shock_index < 0.9 else 'elevated' if shock_index < 1.2 else 'CRITICAL'})")
    explanation.append(f"MAP: {map_mmhg} mmHg ({'normal' if map_mmhg > 65 else 'LOW — organ perfusion risk'})")

    if red_flags:
        explanation.append(f"Red flags triggered: {len(red_flags)}")

    # Top contributing features
    if news_score >= 7:
        explanation.append("HIGH NEWS score is primary driver of risk classification")
    if vitals['spo2_percent'] < 92:
        explanation.append(f"Low oxygen saturation ({vitals['spo2_percent']}%) contributing to high risk")
    if vitals['temperature_c'] > 38.5:
        explanation.append(f"Elevated temperature ({vitals['temperature_c']}°C) detected")

    return {
        'risk_level': RISK_LABELS[risk_pred],
        'risk_code': risk_pred,
        'risk_color': RISK_COLORS[risk_pred],
        'risk_confidence': float(fused_risk_prob[risk_pred] * 100),

        'urgency': URGENCY_LABELS[urgency_pred],
        'urgency_code': urgency_pred,
        'urgency_color': URGENCY_COLORS[urgency_pred],
        'urgency_action': URGENCY_ACTIONS[urgency_pred],
        'urgency_confidence': float(fused_urgency_prob[urgency_pred] * 100),

        'disease': DISEASE_LABELS[disease_pred],
        'disease_confidence': float(fused_disease_prob[disease_pred] * 100),
        'disease_top3': [
            {'name': DISEASE_LABELS[i], 'prob': float(fused_disease_prob[i] * 100)}
            for i in np.argsort(fused_disease_prob)[-3:][::-1]
        ],

        'red_flags': red_flags,
        'red_flag_count': len(red_flags),

        'explanation': explanation,
        'news_score': news_score,
        'shock_index': shock_index,
        'map_mmhg': map_mmhg,
    }


def compute_news_score(vitals):
    """Compute NEWS score from vitals."""
    score = 0
    rr = vitals.get('respiratory_rate', 16)
    if rr <= 8: score += 3
    elif rr <= 11: score += 1
    elif rr <= 20: score += 0
    elif rr <= 24: score += 2
    else: score += 3

    spo2 = vitals.get('spo2_percent', 98)
    if spo2 <= 83: score += 3
    elif spo2 <= 85: score += 3
    elif spo2 <= 87: score += 2
    elif spo2 <= 91: score += 1
    elif spo2 <= 93: score += 1

    temp = vitals.get('temperature_c', 37)
    if temp <= 35.0: score += 3
    elif temp <= 35.9: score += 1
    elif temp <= 38.0: score += 0
    elif temp <= 39.0: score += 1
    else: score += 2

    sbp = vitals.get('bp_systolic_mmhg', 120)
    if sbp <= 70: score += 3
    elif sbp <= 80: score += 3
    elif sbp <= 90: score += 2
    elif sbp <= 100: score += 1
    elif sbp <= 199: score += 0
    elif sbp <= 219: score += 2
    else: score += 3

    hr = vitals.get('heart_rate_bpm', 75)
    if hr <= 40: score += 3
    elif hr <= 50: score += 1
    elif hr <= 90: score += 0
    elif hr <= 110: score += 1
    elif hr <= 130: score += 2
    else: score += 3

    consciousness = vitals.get('consciousness', 'Alert')
    if consciousness == 'Voice': score += 1
    elif consciousness == 'Pain': score += 2
    elif consciousness == 'Unresponsive': score += 3

    return score


# =====================================================================
# ROUTES
# =====================================================================
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json

        vitals = {
            'age': float(data.get('age', 30)),
            'gender': 1 if data.get('gender', 'M') == 'M' else 0,
            'weight_kg': float(data.get('weight_kg', 70)),
            'heart_rate_bpm': float(data.get('heart_rate', 75)),
            'bp_systolic_mmhg': float(data.get('bp_systolic', 120)),
            'bp_diastolic_mmhg': float(data.get('bp_diastolic', 80)),
            'temperature_c': float(data.get('temperature', 37.0)),
            'spo2_percent': float(data.get('spo2', 98)),
            'respiratory_rate': float(data.get('respiratory_rate', 16)),
            'blood_glucose_mg': float(data.get('blood_glucose', 100)),
            'pain_score': float(data.get('pain_score', 3)),
            'consciousness': data.get('consciousness', 'Alert'),
            'is_pregnant': int(data.get('is_pregnant', 0)),
            'has_diabetes': int(data.get('has_diabetes', 0)),
            'has_hypertension': int(data.get('has_hypertension', 0)),
            'has_heart_disease': int(data.get('has_heart_disease', 0)),
            'has_asthma_copd': int(data.get('has_asthma_copd', 0)),
            'has_immunocompromised': int(data.get('has_immunocompromised', 0)),
            'comorbidity_count': 0,
            'nearest_hospital_km': float(data.get('nearest_hospital_km', 25)),
        }

        # Count comorbidities
        vitals['comorbidity_count'] = sum([
            vitals['has_diabetes'], vitals['has_hypertension'],
            vitals['has_heart_disease'], vitals['has_asthma_copd'],
            vitals['has_immunocompromised']
        ])

        symptom_text = data.get('symptoms', 'Patient reports feeling unwell')
        na_fields = data.get('na_fields', [])

        result = predict_triage(vitals, symptom_text)

        # Add NA info to explanation
        if na_fields:
            field_names = {
                'heart_rate': 'Heart Rate', 'spo2': 'SpO2', 'bp_systolic': 'BP Systolic',
                'bp_diastolic': 'BP Diastolic', 'temperature': 'Temperature',
                'respiratory_rate': 'Resp. Rate', 'blood_glucose': 'Blood Glucose',
                'pain_score': 'Pain Score'
            }
            missing = [field_names.get(f, f) for f in na_fields]
            result['explanation'].insert(0,
                f"Equipment limitation: {', '.join(missing)} not available — using estimated normal values. "
                f"NLP model (symptom text) becomes more important for this assessment."
            )

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/manifest.json')
def manifest():
    return send_from_directory(app.static_folder, 'manifest.json')

@app.route('/sw.js')
def service_worker():
    return send_from_directory(app.static_folder, 'sw.js')

@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'models_loaded': True})


# =====================================================================
# RUN
# =====================================================================
if __name__ == '__main__':
    import socket
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)

    print(f"\n{'='*55}")
    print(f"  TRIAGE PWA RUNNING!")
    print(f"{'='*55}")
    print(f"  Computer:  http://localhost:5000")
    print(f"  Phone:     http://{local_ip}:5000")
    print(f"{'='*55}")
    print(f"  On Android Chrome: Menu → 'Add to Home Screen'")
    print(f"  This installs it as an app on your phone!")
    print(f"{'='*55}\n")

    app.run(host='0.0.0.0', port=5000, debug=False)
